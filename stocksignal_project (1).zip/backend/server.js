// server.js - lightweight demo backend (no DB required for demo)
// Run: node server.js
// Emits simulated price ticks over Socket.IO and accepts simple REST signals.
// Note: For production replace simulation with real provider and add DB/auth.

const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(express.json());
app.use(cors());

let liveSymbols = ['NIFTY', 'RELIANCE', 'TCS'];
let priceState = {};

app.get('/api/symbols', (req, res) => {
  res.json({ symbols: liveSymbols });
});

app.post('/api/signals', (req, res) => {
  const { symbol, type, short, long } = req.body;
  console.log('Received signal', req.body);
  io.emit('signal:new', { symbol, type, short, long, time: new Date().toISOString() });
  res.json({ ok: true });
});

io.on('connection', (socket) => {
  console.log('ws connected', socket.id);
  socket.emit('symbols:list', liveSymbols);

  socket.on('subscribe', (sym) => socket.join('sym:' + sym));
});

setInterval(() => {
  liveSymbols.forEach((sym) => {
    const last = priceState[sym] || 100 + Math.random() * 100;
    const change = (Math.random() - 0.5) * 2;
    const next = Math.max(0.01, +(last + change).toFixed(2));
    priceState[sym] = next;
    io.emit('tick', { symbol: sym, price: next, time: new Date().toISOString() });
  });
}, 1000);

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => console.log(`Server listening on ${PORT}`));
