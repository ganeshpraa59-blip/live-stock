import React, { useEffect, useState, useRef } from 'react';

const formatTime = (d = new Date()) => d.toLocaleString();

function computeSma(prices, period) {
  if (prices.length < period) return null;
  const slice = prices.slice(-period);
  return slice.reduce((a, b) => a + b, 0) / period;
}

export default function App() {
  const [symbols, setSymbols] = useState(['NIFTY', 'RELIANCE', 'TCS']);
  const [prices, setPrices] = useState({});
  const [signals, setSignals] = useState([]);
  const [isRunning, setIsRunning] = useState(true);
  const [config, setConfig] = useState({ short: 5, long: 20, alertThreshold: 0.0 });
  const tickRef = useRef(0);

  function addSymbol(sym) {
    if (!sym) return;
    const S = sym.toUpperCase();
    if (symbols.includes(S)) return;
    setSymbols((s) => [...s, S]);
    setPrices((p) => ({ ...p, [S]: [] }));
  }
  function removeSymbol(sym) {
    setSymbols((s) => s.filter((x) => x !== sym));
    setPrices((p) => {
      const cp = { ...p };
      delete cp[sym];
      return cp;
    });
  }

  useEffect(() => {
    const init = {};
    symbols.forEach((sym) => {
      init[sym] = prices[sym] || [Math.round(100 + Math.random() * 1000)];
    });
    setPrices(init);
    // eslint-disable-next-line
  }, []);

  useEffect(() => {
    if (!isRunning) return;
    const interval = setInterval(() => {
      tickRef.current += 1;
      setPrices((prev) => {
        const next = { ...prev };
        symbols.forEach((sym) => {
          const last = (next[sym] && next[sym].length) ? next[sym][next[sym].length - 1] : 100;
          const change = (Math.random() - 0.5) * 2;
          const newPrice = Math.max(0.01, +(last + change).toFixed(2));
          next[sym] = [...(next[sym] || []), newPrice].slice(-200);
        });
        return next;
      });
    }, 1200);
    return () => clearInterval(interval);
  }, [symbols, isRunning]);

  useEffect(() => {
    const now = new Date();
    const newSignals = [];
    symbols.forEach((sym) => {
      const p = prices[sym] || [];
      if (p.length < config.long) return;
      const short = computeSma(p, config.short);
      const long = computeSma(p, config.long);
      const lastSignal = signals.filter((s) => s.symbol === sym).slice(-1)[0];
      if (short && long) {
        if (short > long && (!lastSignal || lastSignal.type !== 'BUY')) {
          newSignals.push({ symbol: sym, type: 'BUY', time: formatTime(now), short, long });
        } else if (short < long && (!lastSignal || lastSignal.type !== 'SELL')) {
          newSignals.push({ symbol: sym, type: 'SELL', time: formatTime(now), short, long });
        }
      }
    });
    if (newSignals.length) setSignals((s) => [...s, ...newSignals].slice(-500));
    // eslint-disable-next-line
  }, [prices]);

  function exportCSV() {
    const head = "symbol,type,time,short,long\n";
    const rows = signals.map((r) => `${r.symbol},${r.type},"${r.time}",${r.short},${r.long}\n`).join("");
    const blob = new Blob([head + rows], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `signals_${new Date().toISOString()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="container">
      <header className="header">
        <h1>Stock Signal Control Panel</h1>
        <div className="time">{formatTime()}</div>
      </header>

      <div className="main">
        <aside className="sidebar">
          <h2>Admin Controls</h2>

          <div>
            <label>Symbols</label>
            <div className="symbols">
              {symbols.map((s) => (
                <div key={s} className="chip">
                  <strong>{s}</strong>
                  <button onClick={() => removeSymbol(s)}>✕</button>
                </div>
              ))}
            </div>
            <div className="add">
              <input id="newSym" placeholder="Add symbol e.g. INFY" />
              <button onClick={() => { const el = document.getElementById('newSym'); if (el && el.value) { addSymbol(el.value.trim()); el.value = ''; }}}>Add</button>
            </div>
          </div>

          <div className="params">
            <label>Signal params</label>
            <div className="param-row">
              <div>
                <div>Short SMA</div>
                <input type="number" value={config.short} onChange={(e) => setConfig((c) => ({ ...c, short: Math.max(1, +e.target.value) }))} />
              </div>
              <div>
                <div>Long SMA</div>
                <input type="number" value={config.long} onChange={(e) => setConfig((c) => ({ ...c, long: Math.max(2, +e.target.value) }))} />
              </div>
            </div>
          </div>

          <div className="controls">
            <button onClick={() => setIsRunning(true)}>Start</button>
            <button onClick={() => setIsRunning(false)}>Pause</button>
            <button onClick={() => setSignals([])}>Clear Signals</button>
          </div>

          <div className="export">
            <button onClick={exportCSV}>Export signals CSV</button>
          </div>

          <div className="note">Note: Front-end demo. For production use a backend, auth, and real market data.</div>
        </aside>

        <main className="content">
          <section className="prices">
            <h3>Live Prices</h3>
            <div className="grid">
              {symbols.map((sym) => (
                <div key={sym} className="card">
                  <div className="row">
                    <div className="symbol">{sym}</div>
                    <div className="price">{prices[sym] ? prices[sym].slice(-1)[0] : '-'}</div>
                  </div>
                  <div className="last10">Last 10: {prices[sym] ? prices[sym].slice(-10).join(', ') : '-'}</div>
                </div>
              ))}
            </div>
          </section>

          <section className="signals">
            <h3>Signal Feed</h3>
            <div className="feed">
              {signals.length === 0 && <div className="muted">No signals yet.</div>}
              {signals.slice().reverse().map((s, i) => (
                <div key={i} className={`feed-item ${s.type === 'BUY' ? 'buy' : 'sell'}`}>
                  <div>
                    <div className="bold">{s.symbol} — {s.type}</div>
                    <div className="small">{s.time} • short: {s.short.toFixed(2)} long: {s.long.toFixed(2)}</div>
                  </div>
                  <div className="actions">
                    <button onClick={() => navigator.clipboard.writeText(JSON.stringify(s))}>Copy</button>
                    <button onClick={() => setSignals((ss) => ss.filter((x) => x !== s))}>Remove</button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </main>
      </div>

      <footer className="footer">Demo SMA signals. Replace with production-grade feed and backend.</footer>
    </div>
  );
}
