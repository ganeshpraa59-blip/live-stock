# LiveStock — Ready-to-Publish (Indian market, dark theme)

This package is pre-configured to deploy quickly:
- **Frontend:** Vite + React (connects to backend via Socket.IO)
- **Backend:** Node.js + Express + Socket.IO (simulated ticks)
- **Market focus:** Indian market (NSE/MCX) — README includes notes to integrate Kite Connect
- **Theme:** Dark

## What you need (3 free accounts)
1. GitHub (to host repo)
2. Vercel (frontend hosting)
3. Render (backend hosting)

---

## Quick deploy (5–10 minutes, click-by-click)

### 1) Create a GitHub repo and upload this project
- Create a new repo on GitHub (e.g. `LiveStock`).
- Upload all files from this package preserving the folder structure (`frontend/`, `backend/`, `README.md`).

### 2) Deploy backend on Render
1. Sign in to Render.com.
2. Click **New** → **Web Service**.
3. Connect GitHub and select your repo, choose the `backend` folder.
4. Build Command: `npm install && npm run build` (no build step needed, but safe) — or leave blank.
5. Start Command: `npm start`
6. Choose free plan and create service.
7. After deploy, note the service URL (e.g. `https://livestock-backend.onrender.com`).

### 3) Deploy frontend on Vercel
1. Sign in to Vercel.com.
2. Click **New Project** → Import Git Repository → choose your repo.
3. In the import settings, set **Root Directory** to `/frontend`.
4. Build Command: `npm run build`  
   Output Directory: `dist`
5. Before deploying, set an Environment Variable:
   - Key: `VITE_WS_URL`
   - Value: `https://<YOUR_RENDER_BACKEND_URL>` (use your Render service URL)
6. Deploy. Vercel will provide the public URL (e.g. `https://livestock.vercel.app`).

### 4) Final check
- Open the Vercel URL. The frontend will connect to backend using `VITE_WS_URL` and start showing simulated ticks and signals.
- To test signals, you can `POST /api/signals` on the backend with `{ "symbol":"RELIANCE", "type":"BUY", "short":123, "long":120 }`.

---

## Integrating real Indian market data (optional, advanced)
- For real NSE/MCX data consider **Zerodha Kite Connect** or **Upstox**:
  - Create a provider account, obtain API keys, and run a backend adapter that subscribes to live websocket ticks.
  - Replace the simulated tick generator in `backend/server.js` with real data and emit `tick` events via Socket.IO.

---

## Files included
- frontend/ (Vite + React)
- backend/ (Node.js server)
- README.md (this file)

---

If you want, I can:
- Push this project to a **new GitHub repo for you** (you'll need to provide GitHub authorization or do it yourself — I can give the exact `git` commands).
- Or I can generate ready-to-run **Dockerfiles** and a single-click deploy manifest.

Tell me: do you want me to (pick one)?
A) Create full `git` commands and the exact steps for you to push to GitHub, OR  
B) Generate Dockerfiles for easy VPS/DigitalOcean deploy, OR  
C) I push to GitHub for you (I'll give instructions — but I cannot run git on your account).  
