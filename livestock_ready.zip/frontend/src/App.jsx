import React, { useEffect, useState, useRef } from 'react';
import { io } from 'socket.io-client';

const formatTime = (d = new Date()) => d.toLocaleString();

function computeSma(prices, period) {
  if (prices.length < period) return null;
  const slice = prices.slice(-period);
  return slice.reduce((a, b) => a + b, 0) / period;
}

export default function App() {
  const [symbols, setSymbols] = useState(['NIFTY', 'RELIANCE', 'TCS']);
  const [prices, setPrices] = useState({});
  const [signals, setSignals] = useState([]);
  const [isRunning, setIsRunning] = useState(true);
  const [config, setConfig] = useState({ short: 5, long: 20 });
  const socketRef = useRef(null);

  useEffect(() => {
    // connect to backend Socket.IO (replace URL when deployed)
    const socket = io(import.meta.env.VITE_WS_URL || 'http://localhost:4000');
    socketRef.current = socket;
    socket.on('connect', () => console.log('connected to ws'));
    socket.on('tick', (t) => {
      setPrices((prev) => {
        const next = { ...prev };
        const sym = t.symbol.toUpperCase();
        next[sym] = [...(next[sym] || []), t.price].slice(-200);
        return next;
      });
    });
    socket.on('signal:new', (s) => {
      setSignals((old) => [...old, { ...s, time: s.time || new Date().toISOString() }].slice(-500));
    });
    socket.on('symbols:list', (list) => {
      setSymbols(list || symbols);
    });
    return () => socket.disconnect();
    // eslint-disable-next-line
  }, []);

  useEffect(() => {
    const now = new Date();
    const newSignals = [];
    symbols.forEach((sym) => {
      const p = prices[sym] || [];
      if (p.length < config.long) return;
      const short = computeSma(p, config.short);
      const long = computeSma(p, config.long);
      const lastSignal = signals.filter((s) => s.symbol === sym).slice(-1)[0];
      if (short && long) {
        if (short > long && (!lastSignal || lastSignal.type !== 'BUY')) {
          newSignals.push({ symbol: sym, type: 'BUY', time: formatTime(now), short, long });
        } else if (short < long && (!lastSignal || lastSignal.type !== 'SELL')) {
          newSignals.push({ symbol: sym, type: 'SELL', time: formatTime(now), short, long });
        }
      }
    });
    if (newSignals.length) setSignals((s) => [...s, ...newSignals].slice(-500));
    // eslint-disable-next-line
  }, [prices]);

  function addSymbolLocal(sym) {
    if (!sym) return;
    const S = sym.toUpperCase();
    if (symbols.includes(S)) return;
    setSymbols((s) => [...s, S]);
  }

  function exportCSV() {
    const head = "symbol,type,time,short,long\n";
    const rows = signals.map((r) => `${r.symbol},${r.type},"${r.time}",${r.short},${r.long}\n`).join("");
    const blob = new Blob([head + rows], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `livestock_signals_${new Date().toISOString()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="app dark">
      <header className="hdr">
        <h1>LiveStock — Indian Market Signals</h1>
        <div className="time">{formatTime()}</div>
      </header>

      <div className="layout">
        <aside className="sidebar">
          <h2>Controls</h2>
          <div className="section">
            <label>Symbols</label>
            <div className="chips">
              {symbols.map((s) => <span key={s} className="chip">{s}</span>)}
            </div>
            <div className="add">
              <input id="newSym" placeholder="Add symbol e.g. INFY" />
              <button onClick={() => { const el = document.getElementById('newSym'); if (el && el.value) { addSymbolLocal(el.value.trim()); el.value=''; }}}>Add</button>
            </div>
          </div>

          <div className="section">
            <label>Signal params</label>
            <div className="row">
              <div><div>Short SMA</div><input type="number" value={config.short} onChange={(e)=>setConfig(c=>({...c,short:Math.max(1,+e.target.value)}))} /></div>
              <div><div>Long SMA</div><input type="number" value={config.long} onChange={(e)=>setConfig(c=>({...c,long:Math.max(2,+e.target.value)}))} /></div>
            </div>
          </div>

          <div className="controls">
            <button onClick={()=>setIsRunning(true)}>Start</button>
            <button onClick={()=>setIsRunning(false)}>Pause</button>
            <button onClick={()=>setSignals([])}>Clear</button>
          </div>

          <div className="export">
            <button onClick={exportCSV}>Export CSV</button>
          </div>

          <div className="note">Demo signals. To connect to live Indian market data, follow README to integrate Kite Connect or other providers.</div>
        </aside>

        <main className="main">
          <section className="prices">
            <h3>Live Prices</h3>
            <div className="grid">
              {symbols.map((sym)=>(
                <div key={sym} className="card">
                  <div className="row2"><div className="sym">{sym}</div><div className="price">{prices[sym]?prices[sym].slice(-1)[0]:'-'}</div></div>
                  <div className="mini">Last: {prices[sym]?prices[sym].slice(-10).join(', '):'-'}</div>
                </div>
              ))}
            </div>
          </section>

          <section className="signals">
            <h3>Signal Feed</h3>
            <div className="feed">
              {signals.length===0 && <div className="muted">No signals yet.</div>}
              {signals.slice().reverse().map((s,i)=>(
                <div key={i} className={`feed-item ${s.type==='BUY'?'buy':'sell'}`}>
                  <div>
                    <div className="bold">{s.symbol} — {s.type}</div>
                    <div className="small">{s.time} • short: {s.short?.toFixed(2)} long: {s.long?.toFixed(2)}</div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </main>
      </div>

      <footer className="ftr">LiveStock — Built for Indian market signals</footer>
    </div>
  );
}
